## Summary

Describe the change and why it is needed.

## Validation

- [ ] `make check` passes.
- [ ] AC-to-battery behavior was tested.
- [ ] Battery-to-AC behavior was tested.
- [ ] Closed-lid behavior was tested, if relevant.
- [ ] Documentation and changelog were updated.
